#pragma sfr
#include "detectsw.h"    /* Standard IO library: sprintf */
#include "r_macro.h"

#include <string.h>
#include "lcd.h"

unsigned int j, k;
unsigned int check;

//unsigned int enable_switch;
extern Delay_10ms();
int match_time;
int enable_switch;
unsigned int check; 
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
int prevoutput = P7_ADR;
int output = P7_ADR;
int prev = P7_ADR;
int current;
int match_times = 0;
/******************************************************************************
* Function Name: getswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
//unsigned int getswitch(){
//	
//	check = PRESS;
//	switch(check){
//		
//		case SW3:
//			if(enable_switch == 1){
//				delay();
//				enable_switch = 0;
//				check = SW3;
//			}else {
//				check = 0;
//			}
//			break;
//			
//		default:
//			delay();
//			enable_switch = 1;
//			check = 0;
//			break;
//	}
//	
//	return check;
//}
void get_SW()
{
			 check = ClearChattering();
}
/******************************************************************************
* Function Name: delay
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
//void delay(){
//	for (j = 0; j < 300; j++){
//		for (k = 0; k < 2000; k++){
//			if(PRESS != 0x07){
//				break;
//			}
//		}
//	}
//}
int ClearChattering(void)
{
	prevoutput = output;
	current = (P7&P7_ADR);
	if(prev!=current)
	{
		match_times=0;
		prev=current;
	}
	else{
		match_times=match_times+1;
		if(match_times>2)
		{
			match_times=0;
			output=current;
			//if (output == 0x20 && prevoutput != 0x20)
			//{
				//prevoutput = P7_ADR;
			//}
		}
		

	}
  	return (output ^ prevoutput) & (~output);
}