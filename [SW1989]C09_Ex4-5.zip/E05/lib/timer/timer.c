#pragma interrupt INTIT r_it_interrupt
#include "timer.h"

volatile int G_elapsedTime = 0; 

void R_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0x1000;       /* disable timer operation */ //***
    ITMK    = 1U;       /* disable timer interrupt */
    ITIF    = 0U;       /* clear timer interrupt flag */

    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */

    ITMC    = 0x012B; /* Configure timer data register */ //***
    
    ITPR1   = 0U;
    ITPR0   = 1U;
}

void R_IT_Start(void)
{
    ITMC    = ITMC | 0x8000;  /* enable timer operation */ //***
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMK    = 0U;       /* enable timer interrupt     */ //***
}

void R_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x7FFF;  /* disable timer operation    */ //***
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
