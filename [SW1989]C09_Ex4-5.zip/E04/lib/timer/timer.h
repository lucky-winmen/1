#ifndef TIMER_H
#define TIMER_H

#include "r_macro.h"  /* System macro and standard type definition */

extern volatile int G_elapsedTime;   // Timer Counter

void R_IT_Create(void);
void R_IT_Start(void);
void R_IT_Stop(void);


#endif