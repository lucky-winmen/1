#ifndef __LED_PORT
#define __LED_PORT

#define PORT6 (volatile unsigned char *)0xFFF06
#define PORT4 (volatile unsigned char *)0xFFF04
#define PORT10 (volatile unsigned char *)0xFFF0A
#define PORT15 (volatile unsigned char *)0xFFF0F

#define Port_Mode_4 (*((volatile char*) 0xFFF24))
#define Port_Mode_6 (*((volatile char*) 0xFFF26))
#define Port_Mode_10 (*((volatile char*)0xFFF2A))
#define Port_Mode_15 (*((volatile char*)0xFFF2F))
#define Port_Mode_7 (*((volatile char*) 0xFFF27))

#define bit0 0x01
#define bit1 0x02
#define bit2 0x04
#define bit3 0x08
#define bit4 0x10
#define bit5 0x20
#define bit6 0x40
#define bit7 0x80

#endif


extern float valuearray[12];	
extern unsigned char *PORT[12];	     
extern unsigned char _value_on[12];	
extern unsigned char _value_off[12];	
extern int _number_led ;


/************************
Function name :init_led
Decription    :This function setting port mode of 12 led 
***********************/
void init_led(void);
/*******************
Function name :turn_led
Decription    :This function use to turn on , turn off led
*******************/
void turn_led(void);
/************************
Function name : check_led_number
Decription    : This function will compare result value of AD conversion with constant value to decide how many led will on
********************************/
void check_led_number(float num);
/**************************
Function name : on_led
Decription    : Turn on led
**************************/
void on_led(int );
/*************************
Function name : off_led
Decription    : Turn off led 
*************************/
void off_led(int);
/**************************
Function name : reduce_noise
Decription    : This function will consider change of AD conversion  result is noise or not , if it is noise
		the value not change , if it isnot noise the result will change 
***************************/
void reduce_noise(float);

/****************************
Function name : Display
Decription    : This function will show to LCD the result 
****************************/
void Display (float);