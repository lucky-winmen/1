#include "r_macro.h"
#include "led.h"
#include "math.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "stdio.h"

/*SET OVERALL_ERROR equal 1.2LSB */
#define OVERALL_ERROR   0.0038 /* overall = (1.2 *3.3)/1023 */


float cur_voltage ;
int _number_led ;
extern float final_voltage;

/************************
Function name :init_led
Decription    :This function setting port mode of 12 led 
***********************/
void init_led()
{
	ADPC =1;
	PM4 &=0xC3;
	PM6 &=0x03;
	PM15 &=0xfb;
	PM10 &=0xfd;
	P6 =0xff;
	P4 =0xff;
	P15 =0xff;
	P10 =0xff;
}
/*******************
Function name :turn_led
Decription    :This function use to turn on , turn off led
*******************/
void turn_led()
{
	check_led_number(final_voltage);
	/*turn on led*/
	on_led(_number_led);
	/*turn off led*/
	off_led(_number_led);
}

/************************
Function name : check_led_number
Decription    : This function will compare result value of AD conversion with constant value to decide how many led will on
********************************/
void check_led_number(float voltage)
{
	int i;
	_number_led = 12;
	/*Compare value with constant value*/
	for (i=0; i <12 ;i++)
	{
		if (voltage < valuearray[i])
		{
			_number_led--;
		}
		else
		{
		}
	}	
}
/**************************
Function name : on_led
Decription    : Turn on led
**************************/
void on_led(int _number_led)
{
	int y ;
	y =0;
	/*assign value for port*/
	while (y < _number_led )
	{
		y++;
		*(PORT[y-1]) &= _value_on[y-1];
	}
}
/*************************
Function name : off_led
Decription    : Turn off led 
*************************/
void off_led(int _number_led)
{
	int off_led_number ;
	int a ;
	off_led_number = 12- _number_led;
	/*Assign value for port*/
	for(a =0; a<= off_led_number;a++)
	{
		*(PORT[(_number_led + a)]) |=  _value_off[(_number_led + a)];
	}
}
/**************************
Function name : reduce_noise
Decription    : This function will consider change of AD conversion  result is noise or not , if it is noise
		the value not change , if it isnot noise the result will change 
***************************/
void reduce_noise(float _voltage)
{
	
	float _voltage_temp;
	_voltage_temp = final_voltage; 
	
	/*consider Error of ADC*/
	if /*(((cur_voltage - _voltage_temp)>OVERALL_ERROR) || ((_voltage_temp - cur_voltage)>OVERALL_ERROR))*/ (abs( cur_voltage - _voltage_temp) > OVERALL_ERROR)
	{
		_voltage_temp = cur_voltage;
	}
	final_voltage = _voltage_temp;
	
	
}

/****************************
Function name : Display
Decription    : This function will show to LCD the result 
****************************/
void Display (float voltage)
{
	
	char buffer[10];
	int decimal_part;
	int unit_part;
	int temp;
	/*Convert result to print*/
	temp = (int)(voltage *100);
	decimal_part = temp/100;
	unit_part =  temp % 100;
	/*Display result*/
	sprintf(buffer ,"%d.%0.2d" , decimal_part,unit_part);
	DisplayLCD(LCD_LINE4 +3, (uint8_t *)buffer);
}