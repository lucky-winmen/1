/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/

/******************************************************************************
Includes 
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */
#include "sw.h"       /* SW driver interface */
#include "api.h"      /* Timer driver interface */
#include "stdio.h"
#include "led.h"

/*****************************************************************************
Define marco
******************************************************************************/
#define FULL_RANGE_SCALE 3.3
#define MAX_LEVEL_ADC	1023

/************************************************************
Define value led red
************************************************************/
#define LED3_ON		0xFB
#define LED5_ON		0x03
#define LED7_ON		0x0B
#define LED9_ON		0x1B
#define LED11_ON	0x3B
#define LED13_ON	0x7B

#define OFF_6LED_RED 	0xff
#define OFF_5LED_RED	0xfb
#define OFF_4LED_RED	0x7B
#define OFF_3LED_RED	0x3B
#define OFF_2LED_RED	0x1B
#define OFF_1LED_RED	0x0B
/*************************************************************
Define value led green
*************************************************************/
#define LED4_ON		0xC3
#define LED6_ON		0xC7
#define LED8_ON		0xCF
#define LED10_ON	0xDF
#define LED12_ON	0xFB
#define LED14_ON	0xFD

#define OFF_6LED_GREEN	0xff
#define OFF_5LED_GREEN  0xff
#define OFF_4LED_GREEN  0xff
#define OFF_3LED_GREEN  0xdf
#define OFF_2LED_GREEN  0xcf
#define OFF_1LED_GREEN  0xc7


/******************************************************************************
Private global variables and functions
******************************************************************************/
/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;
volatile int G_elapsedTime = 0;   // Timer Counter

/* Global buffer array for storing the ADC
result integer to string conversion  */
extern float cur_voltage ;
float final_voltage;
char string[20];
void LCD_Reset(void);

/*Declare array compared value */

 float valuearray[12]	 ={3.03,2.75,2.48,2.21,1.93,1.65,1.37,1.11,0.83,0.55,0.28,0.15};
 unsigned char *PORT[12] =   {PORT6,PORT10,PORT6,PORT15,PORT6,PORT4,PORT6,PORT4,PORT6,PORT4,PORT6,PORT4};
 unsigned char _value_on[12] ={LED3_ON,LED14_ON,LED13_ON,LED12_ON,LED11_ON,LED10_ON,LED9_ON,LED8_ON,LED7_ON,LED6_ON,LED5_ON,LED4_ON};
 unsigned char _value_off[12]={OFF_6LED_RED,OFF_6LED_GREEN,OFF_5LED_RED,OFF_5LED_GREEN,OFF_4LED_RED,OFF_4LED_GREEN,OFF_3LED_RED,OFF_3LED_GREEN, OFF_2LED_RED,OFF_2LED_GREEN,OFF_1LED_RED,OFF_1LED_GREEN};	

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	
	/*Initialize led*/
	init_led();
	/* Initialize ADC module */
        ADC_Create();
	ADC_Set_OperationOn();
	
	/* Enable interrupt */
	EI();
	
	LCD_Reset();
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Initialize timer */
	 R_IT_Create();
	/* Enable timer */
	
	R_IT_Start();
	/* Display information on the debug LCD.*/
	DisplayLCD(LCD_LINE1+2, (uint8_t *)"Voltage ");
	DisplayLCD(LCD_LINE2+2, (uint8_t *)" of VR1");
	
	/* Main loop - Infinite loop */
	/* Halt program in an infinite while loop */
	while (1U)
	{
	    if ( G_elapsedTime >= 10)
	    {
		/* Declare a temporary variable */
		uint8_t a;
		
		/* Start an A/D conversion */
		ADC_Start();

		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);

		/* Clear ADC flag */
		Adc_Status = 0;

		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR >> 6;

		/* Convert ADC result into a character string, and store in the local */
		cur_voltage = (gADC_Result*FULL_RANGE_SCALE)/MAX_LEVEL_ADC;
		
		/* reduce noise*/
		reduce_noise(cur_voltage);

		/*Turn led*/
		turn_led();
		
		/* Display the contents of the local string lcd_buffer */
		Display(final_voltage);

		 G_elapsedTime =0;
	    }
	    else
	    {
                /* Do nothing */
	    }
	}
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}

__interrupt static void r_it_interrupt(void)
{
    
	G_elapsedTime++;
   
}
/******************************************************************************
End of file
******************************************************************************/
