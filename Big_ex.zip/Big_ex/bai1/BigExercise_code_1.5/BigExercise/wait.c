#include "wait.h"
#include "timer.h"    /* Timer driver interface */
extern int wait_flag; 
extern int State;
extern int co_ngat;
extern int runout_flag;
extern wait1ms();

/********************Define delay function using assembly*/
//#define ASM_wait

 /******************************************************************************
* Function Name: wait
* Description  : Delay 1 s
* Arguments    : none
* Return Value : none
******************************************************************************/
void wait(void)
{
	int i ;
	for (i =0 ; i <1778; i++)
	{
		int j= 2000 ;
		while (j >0)
		{
			j--;
		}		
	}
	i = 0 ;
	wait_flag =1;
}

 /******************************************************************************
* Function Name: count_down
* Description  : count_down value of g_time in Counting status
* Arguments    : none
* Return Value : none
******************************************************************************/
void count_down(void)
{
	
#ifdef ASM_wait
	int i =1000;
	while( i > 0)
	{
		i = i -1;
		/*call delay function assembly*/
		wait1ms();
	}// count down 1 s
	wait_flag =1;
#else
	
	/*call delay function*/
	wait();
#endif
  /******************************************************************************
* Function Name: check Count_down
* Description  : count_down value of g_time in Counting status
		end of second ( minute --) 
		end of second and end of minute ( runout_flag = 1)
* Arguments    : none
* Return Value : none
*****************************************************************************
	/*handle delay interupt*/
	while(wait_flag==1)	
	{
		/*condition to decrease minute value*/	
		 if( (g_time.second) == 0&& g_time.minute !=0 ) 
		{ 	/*decrease minute value */
			g_time.minute--;    
			/*reset max second value */
			g_time.second =59;
		}
		
		
		
		
	else if (g_time.minute ==0 && g_time.second ==0)
		{
			g_time.minute=0;
			g_time.second =0;
			runout_flag=1;
			
		}
		/*decrease second value*/
		else{
			g_time.second--;
		}
		/*reset delay interupt flag*/
		wait_flag =0;			
		
	}
}
/******************************************************************************
* Function Name: delay_interupt 
* Description  : check current state to fiLter chattering 
* Arguments    : none
* Return Value : none
******************************************************************************/
void delay_interupt(void)
{
 	
	int i =1000 ;
	while (i >0 )
	{
		int j =600;
		i --;
		while (j>0)
		{
			j--;
			
		}
	}
	
	
}