/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : intp_isr.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"
#include "wait.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern int State  ;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/

extern  int co_ngat ;


/******************************************************************************
* Function Name: intp8_isr
* Description  : Interrupt service routine for INTP8 (SW2)
*              : In setting State (State = 0) SW2ter inupt will add minute value with 1
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp8_isr(void){
	/*Set status is Setting*/
	//PMK8 = 1;	/* Disable INTP8 operation  SWITCH 2*/
	//PIF9 =0;	/* Clear INTP9 interrupt flag SWITCH 3*/
	//PIF10 =0;	/* Clear INTP10 interrupt flag SWITCH 1*/
		
	switch(State)
	{
	/*Handle when overflow second value*/
		default:/*Increase minute value */
			delay_interupt();
			g_time.minute++;
			if (g_time.minute >= 60 )
			 {
				g_time.minute= 0;
			 }
			break;
		case 2 : /*if state = pause*/
			delay_interupt();
			 State =0;
			 g_time.second =0;
			 g_time.minute =0;
			 break;
		case 1 :/*if state = count down*/
				break;
	}

	co_ngat =1;
	//PIF8 =0;
	//PMK8= 0;
}

/******************************************************************************
* Function Name: intp9_isr
* Description  : Interrupt service routine for INTP9 (SW3)
*              : In setting State (State = 0 ) Switch 3 interupt will change State , from setting (State = 0) to counting (State =1)
		 If current is Counting State(State = 1) it will be change to Pause State( State = 2)  
		 If current is Pause State (State =2) it will be change to Counting State (State =1)
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp9_isr(void)
{	//PMK9 = 1;
	//PIF8 =0;
	//PIF10 =0;
	
	/*Select status*/
	switch (State){
		/*Switch to Counting status*/
		case 0 :/*delay to reduce noise*/
			delay_interupt();
			if (g_time.minute !=0 || g_time.second!=0)
				{
					State = 1;
				}
			break;
		/*Switch to Paused status*/			
		case 1 : 	/*delay to reduce noise*/
				delay_interupt();
				State = 2;
				g_time.second ++;
				if (g_time.second>60)
				{
					g_time.minute++;
				}
				break;
		/*Switch to Counting status*/	
		case 2 :	/*delay to reduce noise*/
				delay_interupt();
				State = 1;
				break;
		/*Default status*/		
		default :	State =0 ;
				/*reset all time value*/
				g_time.minute = 0;
				g_time.second = 0;
				break;
	}
	
	/*enable interupt flag*/
	co_ngat =1;
	//PIF9 =0;
	//PMK9= 0;
}

/******************************************************************************
* Function Name: intp10_isr
* Description  : Interrupt service routine for INTP10 (SW1)
*              : TODO: Increase minute value
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp10_isr(void)

{	
	//PMK10 = 1;
	//PIF8 =0;
	//PIF9 =0;	
	if (State == 0)
	{	
		//delay to reduce noise*/
		delay_interupt();
		/*Increase second value */
		g_time.second++;
		/*reset value if over 60*/
		if (g_time.second >= 60 )
			{
				g_time.second= 0;
			}
		
		/*enable interupt flag*/
		co_ngat=1;
	}
	else
	{
		NOP();
	}
	
	//PIF10 =0;
	//PMK10= 0;
}
 

/******************************************************************************
End of file
******************************************************************************/

