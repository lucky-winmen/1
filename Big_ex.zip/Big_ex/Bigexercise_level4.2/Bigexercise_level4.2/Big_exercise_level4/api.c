#include "api.h"

void R_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0U;       /* disable timer operation */
    ITMK    = 1U;       /* disable timer interrupt */
    ITIF    = 0U;       /* clear timer interrupt flag */

    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */

    ITMC    = 95U; /* Configure timer data register */
    			/*1centi second*/
}

void R_IT_Start(void)
{
    ITMC    = 0x8095U;  /* enable timer operation     */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMK    = 0U;       /* enable timer interrupt     */
}

void R_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x000FU;  /* disable timer operation    */
}
