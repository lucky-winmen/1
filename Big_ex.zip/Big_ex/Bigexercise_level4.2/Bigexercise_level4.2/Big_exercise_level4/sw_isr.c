#include "r_macro.h" 
#include "lcd.h"
#include "uart.h"
#include "led.h"



extern int error_flag;





/******************************************************************************
* Function Name: intp9_isr
* Description  : Interrupt service routine for INTP9 (SW3)
*              : In setting State (State = 0 ) Switch 3 interupt will change State , from setting (State = 0) to counting (State =1)
		 If current is Counting State(State = 1) it will be change to Pause State( State = 2)  
		 If current is Pause State (State =2) it will be change to Counting State (State =1)
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp9_isr(void)
{	
	PMK9 = 1;
	
	delay();
	error_flag = NO_ERROR;
	ClearLCD();
	P1_bit.no0 = 0;
	PIF9 =0;
	PMK9= 0;
}
