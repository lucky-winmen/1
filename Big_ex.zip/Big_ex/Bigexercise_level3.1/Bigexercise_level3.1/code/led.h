#ifndef __LED_PORT
#define __LED_PORT

#define PORT6 (volatile unsigned char *)0xFFF06
#define PORT4 (volatile unsigned char *)0xFFF04
#define PORT10 (volatile unsigned char *)0xFFF0A
#define PORT15 (volatile unsigned char *)0xFFF0F

#endif


extern float valuearray[12];	
extern unsigned char *PORT[12];	     
extern unsigned char _value_on[12];	
extern unsigned char _value_off[12];	
extern int _number_led ;


/************************
Function name :ledinit
Decription    :This function setting port mode of 12 led 
***********************/
void ledinit(void);
/*******************
Function name :turn_led
Decription    :This function use to turn on , turn off led
*******************/
void turn_led(void);
/************************
Function name : check_led_number
Decription    : This function will compare result value of AD conversion with constant value to decide how many led will on
********************************/
void check_led_number(float num);
/**************************
Function name : on_led
Decription    : Turn on led
**************************/
void on_led(int );
/*************************
Function name : off_led
Decription    : Turn off led 
*************************/
void off_led(int);
/**************************
Function name : detect_noise
Decription    : This function will consider change of AD conversion  result is noise or not , if it is noise
		the value not change , if it isnot noise the result will change 
***************************/
void detect_noise(float);

/****************************
Function name : Display_result
Decription    : This function will show to LCD the result 
****************************/
void Display_result (float);