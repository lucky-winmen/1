#include "wait.h"
#include "timer.h"    /* Timer driver interface */
extern int wait_flag; 
extern int State;
extern int intp_flag;


 /******************************************************************************
* Function Name: wait
* Description  : Delay 1 s
* Arguments    : none
* Return Value : none
******************************************************************************/
void wait(void)
{
	int i ;
	for (i =0 ; i <1790; i++)
	{
		int j= 2000 ;
		while (j >0)
		{
			j--;
		}		
	}
	i = 0 ;
	wait_flag =1;
}

 /******************************************************************************
* Function Name: count_down
* Description  : count_down value of g_time in Counting status
* Arguments    : none
* Return Value : none
******************************************************************************/
void count_down(void)
{
	/*call delay function*/
	wait();	
	/*handle delay interupt*/
	while(wait_flag==1)	
	{
		/*condition to decrease minute value*/	
		 if( (g_time.second) == 0&& g_time.minute !=0 ) 
		{ 	/*decrease minute value */
			g_time.minute--;    
			/*reset max second value */
			g_time.second =59;
		}
		
		
		
		
		else if (g_time.minute ==0 && g_time.second ==0)
		{
			g_time.minute=0;
			g_time.second =0;
			while(intp_flag != 0)
			{
			}
		}
		/*decrease second value*/
		else{
			g_time.second--;
		}
		/*reset delay interupt flag*/
		wait_flag =0;			
		
	}
}
/******************************************************************************
* Function Name: delay_interupt 
* Description  : check current state to fitter chattering 
* Arguments    : none
* Return Value : none
******************************************************************************/
void delay_interupt(void)
{
 	
	int i =1000 ;
	while (i >0 )
	{
		int j =550;
		i --;
		while (j>0)
		{
			j--;
		}
	}
	
	
}