#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"
#include "lcd.h"
#include "string.h"


/******************************************************************************
Typedef definitions
******************************************************************************/

/*Structure of record memory */
typedef struct
{
	char a[15];
}record ;


/******************************************************************************
* Function Name: check_record
* Description  : Check Record exist or not
* Arguments    : none
* Return Value : none
******************************************************************************/
void check_record(void);


/******************************************************************************
* Function Name:  increase_value
* Description  : increase value of time and print this
* Arguments    : none
* Return Value : none
******************************************************************************/

void increase_value(void);

/******************************************************************************
* Function Name: Save_record
* Description  : Save new_record after press SW3 , and display this 
* Arguments    : none
* Return Value : none
******************************************************************************/

void Save_record(void);

/******************************************************************************
* Function Name: Scroll_up
* Description  : Using to scroll up the list record
* Arguments    : none
* Return Value : none
******************************************************************************/

void Scroll_up(void);

/******************************************************************************
* Function Name: Scroll_down
* Description  : Using to scroll down the list record
* Arguments    : none
* Return Value : none
******************************************************************************/
void Scroll_down(void);


/******************************************************************************
* Function Name: Back
* Description  : Check State to print again after  Scroll
* Arguments    : none
* Return Value : none
******************************************************************************/
void Back(void);


/******************************************************************************
* Function Name: shiftarray
* Description  : Shift value when number of record over max length of record
* Arguments    : none
* Return Value : none
******************************************************************************/
void shiftarray(void);

/******************************************************************************
* Function Name: reset_value
* Description  : reset all value and change to PAUSING State
* Arguments    : none
* Return Value : none
******************************************************************************/

void reset_value(void);