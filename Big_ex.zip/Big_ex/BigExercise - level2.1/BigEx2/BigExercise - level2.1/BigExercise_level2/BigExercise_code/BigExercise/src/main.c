/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "timer.h"    /* Timer driver interface */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "string.h"   /* String header*/
#include "api.h"      /* timer header*/
#include "check_record.h"
#include "detectSwitch.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define PAUSING 1
#define RUNNING 2
#define NO_RECORD 3
#define FIRST_RECORD 4
#define LAST_RECORD 5
#define CAN_SCROLL 6
#define TWO_SECOND 200
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/


/******************************************************************************
Private global variables and functions
******************************************************************************/


extern char buff[20];			/*Buffer used to display result*/
extern int State;			/* Status of program*/
extern int centi_sec_flag;
extern int t2s;

time_t g_time;				/* Structure of time */

int record_status;			/*Status of record memory*/
unsigned int check;			/*Check Switch variable*/
unsigned int enable_switch ;		/*Check enable Switch*/

void r_main_userinit(void);		/* Init function*/


/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
 {	
	/* Initialize user system */
	r_main_userinit();
	/* Clear LCD display */
	ClearLCD();
	/*Initialize State*/
	State = PAUSING ;
	/*Initialize display LCD*/	
	DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing...");
	sprintf( buff , "%0.2d:%0.2d:%0.2d", g_time.minute , g_time.second,g_time.centi_second);
	DisplayLCD(LCD_LINE2, (uint8_t *)buff);
	/*init timer*/
	R_IT_Create();
	/*enable Switch*/
	enable_switch =1;	
	/* Main loop - Infinite loop */
	while(1)
	{	
		/*Start timer*/
		R_IT_Start();	
		
		/*Print state after delay 2 s*/
		if( t2s== TWO_SECOND)
			{
				Back();					
			}
		if (State == RUNNING)
		{ 	
			
			if(centi_sec_flag ==1)
			{
				/*Increase time value*/
				increase_value();
				
				/*check switch*/
				check = getswitch();
				
				/*if press Switch 1*/
				if(check == SW1)
					{
						/*check record*/
						check_record();
						/*if record = null , print "no record"*/
						/* not null , scroll up*/	
						/* if first record , print and Delay 2s*/
						if ( record_status == CAN_SCROLL)
						{
						Scroll_up();
						}
						
							
					
					}
				/*if press Switch 2*/
				if (check  == SW2)
					{
						/*check record*/
						check_record();
						/*if record = null , print "no record"*/
							
						/* if last record , print and Delay 2s*/
						/* not null , scroll down*/
						if ( record_status == CAN_SCROLL)
						{
						Scroll_down();
						}
					
					}
				/*if press Switch 3*/
				if (check  == SW3)
					{
	
						/*save record*/
						Save_record();
					}
				/*if  press Switch 1_2*/
				if (check  == SW1_2)
					{
						/*keep value */
						R_IT_Stop();	
						/*change to pausing state*/
						State = PAUSING;
						/*Reset timer delay 2s*/
						t2s =200;
					}
			}
		}
			
		if(State==PAUSING)
			{	
				/*check switch*/
				check= getswitch();
				/*if  press Switch 1_2*/
				if(check== SW1_2)
				{
					/*reset value*/
					reset_value();
					/*keep in PAUSING*/
					State = PAUSING;
					/*Keep timer delay 2s*/
					t2s=200;
				
				}
				if(check  == SW2)
				{
					
						/*check record*/
						check_record();
						/*if record = null , print "no record"*/
						/* not null , scroll down*/	
						/* if last record , print and Delay 2s*/
						if ( record_status == CAN_SCROLL)
						{
						Scroll_down();
						}
						
				}
				/*if press Switch 1*/
				if(check == SW1)
				{
					
						/*check record*/
						check_record();
						/*if record = null , print "no record"*/
						/* not null , scroll up*/	
						/* if first record , print and Delay 2s*/
						if ( record_status == CAN_SCROLL)
						{
						Scroll_up();
						}
					
				}
				/*if press Switch 3*/
				if (check  == SW3)
				{
					/*Change State to RUNNING status*/
					State = RUNNING;
					/*Display State */
					DisplayLCD(LCD_LINE1, (uint8_t *)"RUNNING...");
					/*Keep timer delay 2s*/
					t2s =200;
				}
			}
	}	
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}


/******************************************************************************
End of file
******************************************************************************/