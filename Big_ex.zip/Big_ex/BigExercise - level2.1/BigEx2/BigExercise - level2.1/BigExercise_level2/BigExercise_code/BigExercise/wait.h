


#ifndef __WAIT_H
#define __WAIT_H

void wait(void);
void count_down(void);
void delay_interupt(void);
#endif