#include "check_record.h"
#include "lcd.h"
#include "string.h"
#include "detectSwitch.h"
#include "timer.h"
#include <stdio.h>
/******************************************************************************
Macro definitions
******************************************************************************/
#define PAUSING 1
#define RUNNING 2
#define NO_RECORD 3
#define FIRST_RECORD 4
#define LAST_RECORD 5
#define CAN_SCROLL 6



extern int t2s ;
extern int record_status ;
extern unsigned int check;

int State ;
int num_record =0;
int max_record =0;
int centi_sec_flag ;
int Scroll;

record data[22];
char buff[20];

/******************************************************************************
* Function Name: check_record
* Description  : Check Record exist or not
* Arguments    : none
* Return Value : none
******************************************************************************/

void check_record()
{
	
	if (max_record ==0)/*Check no record*/
	{
				/*Display record Status*/
				DisplayLCD(LCD_LINE1 ,(uint8_t*) "No Record");
				record_status = NO_RECORD;
				/*reset timer then wait 2second to print state*/
				t2s =0;
							
	}	
	else if ((max_record <7) && (check ==SW1))
	{
				/*Display record Status*/
				DisplayLCD(LCD_LINE1 ,(uint8_t*) "First Record");
				record_status = FIRST_RECORD;
				/*reset timer then wait 2second to print state*/
				t2s =0;
	}
	else if ((max_record <7) && (check ==SW2))
	{
				/*Display record Status*/
				DisplayLCD(LCD_LINE1 ,(uint8_t*) "Last Record");
				record_status = LAST_RECORD ;
				/*reset timer then wait 2second to print state*/
				t2s =0;
	}
	else /*If have record*/
	{
				record_status = CAN_SCROLL;
	}
	
}



/******************************************************************************
* Function Name: Back
* Description  : Check State to print again after  Scroll
* Arguments    : none
* Return Value : none
******************************************************************************/

void Back()
{
		if (State== RUNNING )
		{
			DisplayLCD(LCD_LINE1 ,(uint8_t*) "RUNNING...");
		}
		if(State == PAUSING)
		{
			DisplayLCD(LCD_LINE1 ,(uint8_t*) "PAUSING...");
		}
}


/******************************************************************************
* Function Name: Save_record
* Description  : Save new_record after press SW3 , and display this 
* Arguments    : none
* Return Value : none
******************************************************************************/




void Save_record()
{
	
	num_record++;
	max_record++;
	/*reset Scroll variable*/ 
	/*Will srcoll again from last record*/
	Scroll =0;
	/*Print new line of time value*/
	sprintf( buff , "%0.2d:%0.2d:%0.2d", g_time.minute , g_time.second,g_time.centi_second);	
	DisplayLCD(LCD_LINE2, (uint8_t *)buff);
	
	if (max_record >21)
	{
		max_record =21;
	}
	/*save new data in last record*/
	sprintf( data[max_record].a , "#%d:%0.2d:%0.2d:%0.2d",num_record, g_time.minute , g_time.second,g_time.centi_second);
	
	/*if not Scrolling*/
	
		if (max_record <7) /*If number of record <6*/
			{
				int i;
				i=0;
				for(i =1 ; i <= max_record; i++)
				{	
					unsigned char x = (unsigned char)(LCD_LINE2 + i*8);
					DisplayLCD(x,(uint8_t *)data[i].a);
				}
			}
		if (max_record >=7 && max_record <=20)/*if number of record >=6 till number of record <= max number*/
			{
				int i,y;
				i=0;
				y=1;
				
					for(i = max_record -6 ; i < max_record; i++)
					{	
						unsigned char x = (unsigned char)(LCD_LINE2 + y*8);
						DisplayLCD(x,(uint8_t *)data[i+1].a);
						y++;
						
					}
			
			}
		if (max_record >20)	/*if number of record > max number*/
			{ 
				int i,y;
				i=0;
				y=1;
				
				shiftarray();/*shift array*/
				strcpy (data[20].a , data[max_record].a);
				
					for(i = max_record -6 ; i < max_record; i++)
					{	
						
						unsigned char x = (unsigned char)(LCD_LINE2 + y*8);
						DisplayLCD(x,(uint8_t *)data[i].a);
						y++;
							
					}
				
				max_record =20;
			}
	
}






/******************************************************************************
* Function Name: shiftarray
* Description  : Shift value when number of record over max length of record
* Arguments    : none
* Return Value : none
******************************************************************************/
void shiftarray()
{
	int i;
	for(i=1; i <21;i++)
	{
		strcpy (data[i].a ,data[i+1].a);
	}
}



/******************************************************************************
* Function Name:  increase_value
* Description  : increase value of time and print this
* Arguments    : none
* Return Value : none
******************************************************************************/

void increase_value()
{
	
		if (State == RUNNING)
			{
			
				g_time.centi_second = g_time.centi_second + 10;
				
				if (g_time.centi_second >= 100)
				{
					g_time.centi_second =0;
					g_time.second ++;
				}
				if (g_time.second >59)
				{
					g_time.second = 0;
					g_time.minute ++;
				}
				if (g_time.minute >60)
				{	g_time.minute =0;
				}
			}
		if (State ==PAUSING)
			{/*do not thing*/
			}
	
		centi_sec_flag  =0;

		/*print value*/
		sprintf( buff , "%0.2d:%0.2d:%0.2d", g_time.minute , g_time.second,g_time.centi_second);
		DisplayLCD(LCD_LINE2, (uint8_t *)buff);		
	
}

/******************************************************************************
* Function Name: reset_value
* Description  : reset all value and change to PAUSING State
* Arguments    : none
* Return Value : none
******************************************************************************/

void reset_value()
{
	int i ;
	int y ;
	for (i=0; i < max_record;i++)
	{
		
		sprintf( data[i].a , "%s","            ");		
	}
	/*reset time value*/
	g_time.minute =0;
	g_time.second = 0;
	g_time.centi_second =0;
	/*reset list of data record*/
	max_record =0;
	num_record =0;
	
	
	ClearLCD();
	/*Print new line of time value*/
	sprintf( buff , "%0.2d:%0.2d:%0.2d", g_time.minute , g_time.second,g_time.centi_second);	
	DisplayLCD(LCD_LINE2, (uint8_t *)buff);
	
}



/******************************************************************************
* Function Name: Scroll_up
* Description  : Using to scroll up the list record
* Arguments    : none
* Return Value : none
******************************************************************************/

void Scroll_up()
{
	
	int i,y;
	i=0;
	y=1;
	Scroll++;
	
	
	/*IF the upper record is nothing so print first record*/
	if (Scroll >= max_record-6)
	{
		Scroll = max_record-6;
		DisplayLCD(LCD_LINE1 , (uint8_t*)"First Record");	
		record_status =FIRST_RECORD ;						/* Assign variable value to sure in next check */
		t2s  =0;								/*reset timer value to back the state after 2second*/	
	}
	else
	{
		Back();	
	}
	
	
	for(i =(max_record -5) - Scroll ; i <= max_record- Scroll; i++)
	{	
		unsigned char x = (unsigned char)(LCD_LINE2 + y*8);		/*Display data*/
		DisplayLCD(x,(uint8_t *)data[i].a);
		y++;				
	}	
}






/******************************************************************************
* Function Name: Scroll_down
* Description  : Using to scroll down the list record
* Arguments    : none
* Return Value : none
******************************************************************************/
void Scroll_down()
{
	
	int i,y;
	i=0;
	y=1;
	Scroll--;
	
	
	/*IF previous record is the last record , we check and print it*/
	if (Scroll <=0)
	{
		Scroll = 0;
		DisplayLCD(LCD_LINE1 ,(uint8_t*) "Last Record");
		record_status =LAST_RECORD;					/* Assign variable value to sure in next check */
		t2s =0;								/*reset timer value to back the state after 2second*/		
	}
	else
	{
		Back();	
	}
	/*Scroll down list nomarlly */
	for(i =(max_record -5) - Scroll ; i <= max_record- Scroll; i++)
	{	
		unsigned char x = (unsigned char)(LCD_LINE2 + y*8);
		DisplayLCD(x,(uint8_t *)data[i].a);			/*Display data*/
		y++;				
	}
	
	
}