
#include "detectSwitch.h"    /* Standard IO library: sprintf */


unsigned int j, k;
extern unsigned int check;

/******************************************************************************
* Function Name: getswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
unsigned int getswitch(){

extern unsigned int enable_switch;	
	check = PRESS;
	switch(check){
		case SW1:
			if(enable_switch == 1){
				delay();
				enable_switch = 0;
				check = SW1;
			}else {
				check = 0;
			}
			break;
			
		case SW2:		
			if(enable_switch == 1){
				delay();
				enable_switch = 0;
				check = SW2;
			}else {
				check = 0;
			}
			break;
	
		case SW3:
			if(enable_switch == 1){
				delay();
				enable_switch = 0;
				check = SW3;
			}else {
				check = 0;
			}
			break;
		case SW1_2:
			while(check == SW1_2){
				delay();
				check = PRESS;
			}
			check = SW1_2;
			break;
			
		default:
			delay();
			enable_switch = 1;
			check = 0;
			break;
	}
	
	return check;
}
int match_times;	
int prevoutput = 0x70;
int output = 0x70;
int prev = 0x70;
int current = 0;
/******************************************************************************
* Function Name: delay
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
int delay(void){

prevoutput = output;
current = (P7&0x70);
	if(prev!=current)
	{
		match_times=0;
		prev=current;
	}
	else{
		match_times=match_times+1;
		if(match_times>2)
		{
			match_times=0;
			output=current;
		}
	}
  return (output ^ prevoutput) & (~output);
}